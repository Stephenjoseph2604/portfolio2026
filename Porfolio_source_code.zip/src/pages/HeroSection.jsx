
// ================= New =====================

import { useEffect, useState } from "react";
import { motion, animate } from "framer-motion";
import {
  ArrowRight, Download, Code2, GitBranch,
  Coffee,  Award,
} from "lucide-react";
// import sj from "../assets/logo/sj2.jpeg";

/* ─── Photos (swap in different shots later) ────────────── */
import { TECHS,CHIPS,ROLES,SKILLS,STATS,PHOTOS } from "../profile";
/* ─── Data ───────────────────────────────────────────────── */

/* ─── Helpers ─────────────────────────────────────────────── */
const PRIMARY   = "#2563eb";
const SECONDARY = "#7c3aed";
const SUCCESS   = "#10b981";

function toRgba(hex, a) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${a})`;
}

/* ═══════════════════════════════════════════════════════
   BACKGROUND
════════════════════════════════════════════════════════ */
function Background() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden" style={{ background: "#050508" }}>
      {[
        { color: PRIMARY,   x: "18%", y: "25%", dur: 18 },
        { color: SECONDARY, x: "72%", y: "18%", dur: 22 },
        { color: "#0f766e", x: "55%", y: "70%", dur: 26 },
      ].map(({ color, x, y, dur }, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            backgroundColor: color,
            left: x, top: y,
            width: "36%", height: "36%",
            filter: "blur(130px)",
            opacity: 0.1,
          }}
          animate={{ x: [0, 40, -25, 0], y: [0, -30, 38, 0], scale: [1, 1.12, 0.92, 1] }}
          transition={{ duration: dur, repeat: Infinity, ease: "easeInOut", delay: i * 2 }}
        />
      ))}
      <div
        className="absolute inset-0 opacity-[0.022]"
        style={{ backgroundImage: "radial-gradient(circle,#94a3b8 1px,transparent 1px)", backgroundSize: "36px 36px" }}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   LEFT SIDE COMPONENTS
════════════════════════════════════════════════════════ */

function AvailableBadge() {
  return (
    <motion.div
      className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border border-[#1e293b] bg-[#080b12] mb-7"
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1, duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
    >
      <span className="relative flex h-2 w-2 flex-shrink-0">
        <span className="absolute inset-0 rounded-full bg-[#10b981] animate-ping opacity-75" />
        <span className="relative rounded-full block h-2 w-2 bg-[#10b981]" style={{ boxShadow: "0 0 6px #10b981" }} />
      </span>
      <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#10b981]">Available</span>
      <span className="text-[10px] text-[#475569]">· Open for Projects & Training</span>
    </motion.div>
  );
}

function Headline() {
  return (
    <div className="mb-6 relative pl-4">
      {/* Left accent bar */}
      <motion.div
        className="absolute left-0 top-0 bottom-0 w-[2px] rounded-full"
        style={{ background: `linear-gradient(180deg,${PRIMARY},${SECONDARY})` }}
        initial={{ scaleY: 0 }}
        animate={{ scaleY: 1 }}
        transition={{ delay: 0.3, duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
      />

      {/* Name */}
      <h1
        className="leading-[0.95] mb-4"
        style={{ fontFamily: "'Syne', sans-serif" }}
      >
        {[
          { text: "Hi, I'm",       style: { fontSize: "clamp(1.5rem,3vw,2.2rem)", background: "linear-gradient(135deg,#94a3b8,#64748b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", fontWeight: 700, letterSpacing: "-0.02em" } },
          { text: "Stephen",       style: { fontSize: "clamp(2.6rem,5.5vw,4rem)",  background: `linear-gradient(135deg,${PRIMARY} 0%,${SECONDARY} 100%)`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", fontWeight: 750, letterSpacing: "-0.04em" } },
          { text: "Joseph",        style: { fontSize: "clamp(2.6rem,5.5vw,4rem)",  background: "linear-gradient(135deg,#ffffff 0%,#94a3b8 70%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", fontWeight: 750, letterSpacing: "-0.04em" } },
        ].map(({ text, style }, i) => (
          <motion.span
            key={i}
            className="block"
            style={style}
            initial={{ opacity: 0, x: -28, filter: "blur(8px)" }}
            animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
            transition={{ delay: 0.28 + i * 0.14, duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          >
            {text}
          </motion.span>
        ))}
      </h1>

      {/* Role badges */}
      <div className="flex flex-wrap gap-2.5">
        {ROLES.map(({ text, Icon, accent }, i) => (
          <motion.div
            key={text}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl border text-sm font-bold"
            style={{
              color: accent,
              borderColor: toRgba(accent, 0.4),
              background: toRgba(accent, 0.08),
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: "0.72rem",
              letterSpacing: "0.04em",
            }}
            initial={{ opacity: 0, y: 16, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.72 + i * 0.12, type: "spring", stiffness: 300, damping: 22 }}
            whileHover={{ scale: 1.04, boxShadow: `0 6px 18px ${toRgba(accent, 0.25)}` }}
          >
            <Icon className="w-3.5 h-3.5 flex-shrink-0" />
            {text}
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function Bio() {
  return (
    <motion.p
      className="text-sm md:text-[15px] leading-relaxed max-w-md mb-7 text-[#64748b]"
      style={{ fontFamily: "'JetBrains Mono', monospace" }}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.9, duration: 0.55 }}
    >
      I build scalable full-stack applications and empower teams through hands-on corporate
      training in modern web technologies, clean architecture, and real-world delivery.
    </motion.p>
  );
}

function SkillStrip() {
  return (
    <motion.div
      className="flex flex-wrap gap-1.5 mb-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1.05 }}
    >
      {SKILLS.map((s, i) => (
        <motion.span
          key={s}
          className="px-2.5 py-1 text-[9px] font-bold tracking-[0.15em] uppercase rounded-lg border border-[#1e293b] bg-[#080b12] text-[#475569] cursor-default transition-all duration-300 hover:border-[rgba(37,99,235,0.45)] hover:text-[#f1f5f9] hover:bg-[rgba(37,99,235,0.08)]"
          style={{ fontFamily: "'JetBrains Mono', monospace" }}
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.05 + i * 0.055, type: "spring", stiffness: 260, damping: 22 }}
          whileHover={{ y: -2, scale: 1.05 }}
        >
          {s}
        </motion.span>
      ))}
    </motion.div>
  );
}

function CTARow() {
  return (
    <motion.div
      className="flex flex-col sm:flex-row gap-3 mb-10"
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.3, duration: 0.55 }}
    >
      {/* Primary */}
      <motion.a
        href="#contact"
        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-[750] text-sm text-white overflow-hidden relative"
        style={{
          fontFamily: "'Syne', sans-serif",
          letterSpacing: "-0.02em",
          background: `linear-gradient(135deg, ${PRIMARY} 0%, ${SECONDARY} 100%)`,
          boxShadow: `0 8px 26px ${toRgba(PRIMARY, 0.3)}`,
        }}
        whileHover={{ scale: 1.04, y: -2, boxShadow: `0 14px 34px ${toRgba(PRIMARY, 0.42)}` }}
        whileTap={{ scale: 0.97 }}
        transition={{ type: "spring", stiffness: 420, damping: 22 }}
      >
        Let's Work Together
        <ArrowRight className="w-3.5 h-3.5" />
      </motion.a>

      {/* Secondary */}
      <motion.a
        href="/cv.pdf"
        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-sm border border-[#1e293b] bg-[#080b12] text-[#64748b] hover:border-[rgba(37,99,235,0.45)] hover:text-[#f1f5f9] transition-all duration-300"
        style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: "0.75rem", letterSpacing: "0.03em" }}
        whileHover={{ scale: 1.03, y: -1 }}
        whileTap={{ scale: 0.97 }}
      >
        <Download className="w-3.5 h-3.5" />
        Download CV
      </motion.a>
    </motion.div>
  );
}

/* ─── Animated counter ─────────────────────────────────── */
function AnimatedNumber({ value, delay }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const ctrl = animate(0, parseInt(value), {
      duration: 1.8, delay: delay + 0.4, ease: [0.22, 1, 0.36, 1],
      onUpdate: v => setCount(Math.round(v)),
    });
    return ctrl.stop;
  }, []);
  return <>{count}+</>;
}

function StatsRow() {
  return (
    <motion.div
      className="flex flex-wrap gap-5 pt-7 border-t border-[#1e293b]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1.55 }}
    >
      {STATS.map(({ label, value, icon: Icon, accent }, i) => (
        <div key={label} className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center border flex-shrink-0"
            style={{ background: toRgba(accent, 0.1), borderColor: toRgba(accent, 0.3) }}
          >
            <Icon className="w-3.5 h-3.5" style={{ color: accent }} />
          </div>
          <div>
            <p
              className="text-xl font-black leading-none"
              style={{
                fontFamily: "'Syne', sans-serif",
                letterSpacing: "-0.04em",
                color: accent,
              }}
            >
              <AnimatedNumber value={value} delay={1.55 + i * 0.1} />
            </p>
            <p
              className="text-[9px] font-bold uppercase tracking-[0.14em] text-[#475569]"
              style={{ fontFamily: "'JetBrains Mono', monospace" }}
            >
              {label}
            </p>
          </div>
        </div>
      ))}
    </motion.div>
  );
}

/* ═══════════════════════════════════════════════════════
   BENTO GRID — RIGHT SIDE
════════════════════════════════════════════════════════ */

/** Shared cell wrapper */
function BentoCell({ className = "", delay = 0, children, style = {} }) {
  return (
    <motion.div
      className={`relative overflow-hidden rounded-2xl border border-[#1e293b] bg-[#080b12] ${className}`}
      style={style}
      initial={{ opacity: 0, y: 24, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay, duration: 0.62, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ scale: 1.015 }}
    >
      {children}
    </motion.div>
  );
}

/** Photo cell */
function PhotoCell({ src, label, labelIcon: Icon, badge, objectPos = "center top", className = "", delay = 0 }) {
  const [hovered, setHovered] = useState(false);
  return (
    <BentoCell
      className={`group cursor-default ${className}`}
      delay={delay}
      style={{
        boxShadow: hovered ? `0 0 0 1.5px ${toRgba(PRIMARY, 0.4)}, 0 16px 40px ${toRgba(PRIMARY, 0.1)}` : "none",
        transition: "box-shadow 0.4s ease",
      }}
    >
      <motion.img
        src={src} alt={label || "Photo"}
        className="w-full h-full object-cover"
        style={{ objectPosition: objectPos }}
        animate={{ scale: hovered ? 1.06 : 1 }}
        transition={{ duration: 0.6 }}
        draggable={false}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        loading="lazy"
      />
      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#050508]/80 via-[#050508]/20 to-transparent pointer-events-none" />
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{ backgroundImage: "radial-gradient(circle,#94a3b8 1px,transparent 1px)", backgroundSize: "16px 16px" }} />
      {/* Label */}
      {label && (
        <div className="absolute bottom-2.5 left-2.5 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-xl border border-[#1e293b] bg-[#080b12]/90"
          style={{ backdropFilter: "blur(10px)" }}>
          {Icon && <Icon className="w-3 h-3 flex-shrink-0" style={{ color: PRIMARY }} />}
          <span className="text-[9px] font-bold uppercase tracking-[0.15em] text-[#64748b]"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}>{label}</span>
        </div>
      )}
      {/* Badge */}
      {badge && (
        <div className="absolute top-2.5 right-2.5 z-10 px-2 py-0.5 rounded-lg border border-[#1e293b] bg-[#080b12]/90"
          style={{ backdropFilter: "blur(10px)" }}>
          <span className="text-[8px] font-bold uppercase tracking-[0.16em]"
            style={{ color: PRIMARY, fontFamily: "'JetBrains Mono', monospace" }}>{badge}</span>
        </div>
      )}
    </BentoCell>
  );
}

/** Stat cell with animated counter */
function StatCell({ icon: Icon, value, label, accent, className = "", delay = 0 }) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const ctrl = animate(0, parseInt(value), {
      duration: 1.8, delay: delay + 0.5, ease: [0.22, 1, 0.36, 1],
      onUpdate: v => setCount(Math.round(v)),
    });
    return ctrl.stop;
  }, []);

  const [hovered, setHovered] = useState(false);

  return (
    <BentoCell
      className={`flex flex-col p-4 cursor-default ${className}`}
      delay={delay}
      style={{
        boxShadow: hovered ? `0 0 0 1.5px ${toRgba(accent, 0.45)}, 0 12px 30px ${toRgba(accent, 0.12)}` : "none",
        transition: "box-shadow 0.35s ease",
      }}
    >
      <div
        className="relative w-full h-full"
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
      >
        <div className="absolute inset-0 pointer-events-none transition-opacity duration-400"
          style={{ background: `radial-gradient(ellipse 80% 70% at 50% 110%, ${toRgba(accent, 0.18)} 0%, transparent 70%)`, opacity: hovered ? 1 : 0 }} />

        <div className="w-8 h-8 rounded-xl flex items-center justify-center border mb-auto"
          style={{ background: toRgba(accent, 0.1), borderColor: toRgba(accent, 0.3) }}>
          <Icon className="w-4 h-4" style={{ color: accent }} />
        </div>

        <div className=" pt-2">
          <p className="text-2xl font-black leading-none mb-0.5"
            style={{
              fontFamily: "'Syne', sans-serif",
              letterSpacing: "-0.04em",
              color: accent,
              textShadow: hovered ? `0 0 16px ${toRgba(accent, 0.5)}` : "none",
              transition: "text-shadow 0.35s",
            }}>
            {count}+
          </p>
          <p className="text-[9px] font-bold uppercase tracking-[0.15em] text-[#475569]"
            style={{ fontFamily: "'JetBrains Mono', monospace" }}>{label}</p>
        </div>

        <motion.div className="absolute bottom-0 left-0 right-0 h-[2px]"
          animate={{ scaleX: hovered ? 1 : 0 }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          style={{ background: `linear-gradient(90deg, ${accent}, transparent)`, transformOrigin: "left" }} />
      </div>
    </BentoCell>
  );
}

/** Profile identity chip */
function ProfileCell({ className = "", delay = 0 }) {
  return (
    <BentoCell className={`flex items-center gap-3 p-3 cursor-default ${className}`} delay={delay}>
      {/* Avatar */}
      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 font-black text-sm text-white"
        style={{ background: `linear-gradient(135deg,${PRIMARY},${SECONDARY})`, boxShadow: `0 4px 14px ${toRgba(PRIMARY, 0.4)}`, fontFamily: "'Syne',sans-serif" }}>
        SJ
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[11px] font-black text-[#f1f5f9] truncate" style={{ fontFamily: "'Syne',sans-serif", letterSpacing: "-0.02em" }}>
          Stephen Joseph
        </p>
        <p className="text-[9px] text-[#475569]" style={{ fontFamily: "'JetBrains Mono',monospace" }}>
          Full Stack · Trainer
        </p>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <motion.div className="w-1.5 h-1.5 rounded-full bg-[#10b981]"
          animate={{ opacity: [1, 0.25, 1] }} transition={{ duration: 1.3, repeat: Infinity }} />
        <span className="text-[8px] font-bold text-[#10b981]" style={{ fontFamily: "'JetBrains Mono',monospace" }}>LIVE</span>
      </div>
    </BentoCell>
  );
}

/** Marquee cell */

function MarqueeCell({ className = "", delay = 0 }) {
  return (
    <BentoCell className={`flex items-center overflow-hidden ${className}`} delay={delay}>
      <div className="absolute left-0 top-0 bottom-0 w-8 z-10 pointer-events-none"
        style={{ background: "linear-gradient(90deg,#080b12,transparent)" }} />
      <div className="absolute right-0 top-0 bottom-0 w-8 z-10 pointer-events-none"
        style={{ background: "linear-gradient(270deg,#080b12,transparent)" }} />
      <motion.div
        className="flex gap-5 whitespace-nowrap px-4"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
      >
        {[...TECHS, ...TECHS].map((t, i) => (
          <span key={i} className="text-[8px] font-bold uppercase tracking-[0.2em] flex items-center gap-1.5"
            style={{ color: "#334155", fontFamily: "'JetBrains Mono',monospace" }}>
            <span className="w-1 h-1 rounded-full inline-block" style={{ background: toRgba(PRIMARY, 0.5) }} />
            {t}
          </span>
        ))}
      </motion.div>
    </BentoCell>
  );
}

/* ─── Floating ambient chips ─────────────────────────── */
function FloatingChips() {
  return (
    <>
      {CHIPS.map(({ Icon, label, style, delay }, i) => (
        <motion.div
          key={i}
          className="absolute z-40 flex items-center gap-2 px-3 py-2 rounded-xl border border-[#1e293b] bg-[#080b12] pointer-events-none whitespace-nowrap"
          style={{ ...style, backdropFilter: "blur(12px)", boxShadow: "0 8px 24px rgba(0,0,0,0.4)" }}
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay, type: "spring", stiffness: 240, damping: 20 }}
        >
          <motion.div animate={{ y: [0, -3, 0] }} transition={{ duration: 2.4 + i * 0.4, repeat: Infinity, ease: "easeInOut" }}>
            <Icon className="w-3 h-3" style={{ color: PRIMARY }} />
          </motion.div>
          <span className="text-[9px] font-bold uppercase tracking-[0.15em] text-[#64748b]"
            style={{ fontFamily: "'JetBrains Mono',monospace" }}>{label}</span>
        </motion.div>
      ))}
    </>
  );
}

/* ─── Bento grid layout ──────────────────────────────── */
function BentoGrid() {
  return (
    <div
      className="w-full grid gap-2.5"
      style={{
        gridTemplateColumns: "repeat(12, 1fr)",
        gridTemplateRows: "190px 150px 115px auto",
      }}
    >
      {/* Main tall photo */}
      <PhotoCell src={PHOTOS.main} label="Developer" labelIcon={Code2} badge="SJ"
        objectPos="center top"
        className="col-start-1 col-end-6 row-start-1 row-end-4"
        delay={0.3}
      />

      {/* Wide top-right */}
      <PhotoCell src={PHOTOS.top1} label="Trainer" labelIcon={Award}
        objectPos="center 20%"
        className="col-start-6 col-end-13 row-start-1 row-end-3"
        delay={0.42}
      />

      {/* Mid left */}
      <PhotoCell src={PHOTOS.mid1} badge="CODE"
        objectPos="center 35%"
        className="col-start-6 col-end-10 row-start-3 row-end-4"
        delay={0.54}
      />

      {/* Mid right */}
      <PhotoCell src={PHOTOS.mid2} badge="UX"
        objectPos="left 40%"
        className="col-start-10 col-end-13 row-start-3 row-end-4"
        delay={0.62}
      />

      {/* Stat cards */}
      <StatCell icon={GitBranch} value='10' label="Projects Shipped" accent={PRIMARY}
        className="col-start-1 col-end-5 row-start-4 row-end-5" delay={0.72} />
      <StatCell icon={Coffee}    value="2000" label="Students Trained" accent={SECONDARY}
        className="col-start-5 col-end-9 row-start-4 row-end-5" delay={0.80} />

      {/* Profile chip */}
      <ProfileCell className="col-start-9 col-end-13 row-start-4 row-end-5" delay={0.88} />

      {/* Marquee strip */}
      <MarqueeCell className="col-start-1 col-end-13 row-start-5 row-end-6 h-10" delay={0.96} />
    </div>
  );
}

/* ═══════════════════════════════════════════════════════
   MAIN EXPORT
════════════════════════════════════════════════════════ */
export function HeroSection() {
  return (
    <>
      <Background />

      <section
        id="home"
        className="relative min-h-screen  flex items-center pt-24 pb-20 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 xl:gap-16 items-start">

            {/* ── LEFT ── */}
            <div className="flex flex-col items-start">
              <AvailableBadge />
              <Headline />
              <Bio />
              <SkillStrip />
              <CTARow />
              <StatsRow />
            </div>

            {/* ── RIGHT ── */}
            <motion.div
              className="relative w-full hidden lg:block"
              initial={{ opacity: 0, x: 36 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.85, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            >
              <FloatingChips />
              <BentoGrid />
              {/* Outer glow */}
              <div className="absolute inset-0 -z-10 blur-[80px] opacity-15 rounded-3xl pointer-events-none"
                style={{ background: `radial-gradient(ellipse at 60% 40%, ${PRIMARY}, transparent 70%)` }} />
            </motion.div>

          </div>
        </div>

        {/* Bottom fade */}
        <div className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
          style={{ background: "linear-gradient(to top, #050508, transparent)" }} />
      </section>
    </>
  );
}

export default HeroSection;