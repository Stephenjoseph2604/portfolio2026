import {
   Code2, Users, GitBranch,
  Coffee, Zap, Terminal, Star, Award,
} from "lucide-react";
import prof from './assets/training/prof.webp'
import t5 from './assets/training/t51.webp'
import t22 from './assets/training/t22.webp'
import t16 from './assets/training/t16.webp'
import t32 from './assets/training/t32.jpeg'
import t33 from './assets/training/t33.png'
export const PHOTOS = { main: prof, top1: t33, mid1: t22, mid2: t16 };
export const TECHS = ["React", "Spring Boot", "Node.js", "MySQL", "MongoDB", "Kotlin", "Tailwind", "JWT", "Docker"];
export const SKILLS = ["Java", "Spring Boot","React", "Node.js", "MySQL", "MongoDB", "Kotlin"];
export const STATS  = [
  { label: "Projects Shipped", value: "10", icon: GitBranch, accent: "#2563eb" },
  { label: "Students Trained",    value: "2000", icon: Coffee,    accent: "#7c3aed" },
  { label: "Years XP",         value: "3",   icon: Award,     accent: "#10b981" },
];
export const ROLES = [
  { text: "Full Stack Developer", Icon: Code2,  accent: "#2563eb" },
  { text: "Corporate Trainer",    Icon: Users,  accent: "#10b981" },
];
export const CHIPS = [
  { Icon: Zap, label: "Excellence", style: { top: "2%", right: "-3%" }, delay: 1.1 },
  { Icon: Terminal, label: "Delivering Solutions", style: { top: "44%", right: "-5%" }, delay: 1.3 },
  { Icon: Star, label: "Proven Results", style: { bottom: "35%", left: "-4%" }, delay: 1.5 },
];